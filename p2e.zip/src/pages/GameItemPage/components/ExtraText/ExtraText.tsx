import styles from "./ExtraText.module.scss"

export const ExtraText = () => {
    return <div className={styles.extraText}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio tenetur quaerat quibusdam quasi totam esse? Voluptatum, impedit minima! Veritatis aliquam animi voluptatibus, odit soluta laudantium quas atque maxime at minima.
    </div>
}